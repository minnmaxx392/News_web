// Lấy nút Tổng hợp tin
// const newsAggregatorButton = document.querySelector('.button.news-aggregator');

// // Lấy nội dung chính
// const mainContent = document.querySelector('.main-content');

// // Thêm sự kiện click vào nút Tổng hợp tin
// newsAggregatorButton.addEventListener('click', () => {
//   // Hiển thị nội dung chính
//   mainContent.style.display = 'block';
// });


// function submitForm(event) {
// event.preventDefault();

// // Lấy dữ liệu từ biểu mẫu
// const formData = new FormData(document.getElementById('search-form'));

// // Gửi yêu cầu AJAX
// fetch(urls.py, {
//   method: 'POST',
//   body: formData,
// })
// .then(response => response.json())
// .then(data => {
//   // Cập nhật nội dung trang
//   document.getElementById('results').innerHTML = data.html;
// });
// }
